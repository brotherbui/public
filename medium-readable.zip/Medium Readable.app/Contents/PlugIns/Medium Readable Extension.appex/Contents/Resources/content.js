
// This function will replace the body of the current page with an iframe
function replaceContentWithIframe(iframeSrc) {
  var iframe = document.createElement('iframe');
  iframe.src = iframeSrc;
  iframe.style.width = '100%';
  iframe.style.height = '100vh';
  iframe.style.border = 'none';


  // Select the article element
  var article = document.querySelector('article.meteredContent');

  // Check if the next element sibling is the upgrade popup
  if (article.nextElementSibling) { //&& article.nextElementSibling.matches('div.ab.ca')
    // Remove the div
    article.nextElementSibling.parentNode.removeChild(article.nextElementSibling);
  }

  if (article) {
    article.innerHTML = '';
    article.appendChild(iframe);

  }

}
function hideElements(premiumUrl) {
  const url = new URL(premiumUrl);
  const domain = url.hostname;

  var currentDomain = window.location.hostname;

  if (currentDomain === domain) {
    const header = document.querySelector('#header');
    const openProblemModal = document.querySelector('#openProblemModal');

    if (header) {
      header.style.display = 'none';
    }
    if (openProblemModal) {
      openProblemModal.style.display = 'none';
    }
  }

}

// Retrieve content of the targeted meta tag
function getTargetMetaContent() {
  const metaTag = document.querySelector('meta[property="al:ios:url"]');
  return metaTag ? metaTag.getAttribute('content') : '';
}

// This is the function that handles DOM mutations, specifically targeting meta[property="al:ios:url"]
function handleHeadMutation(mutationsList, observer) {
  for (let mutation of mutationsList) {
    if (mutation.type === 'childList') {
      mutation.addedNodes.forEach(node => {
        if (isTargetMetaTag(node)) {
          const targetUrl = node.getAttribute('content');
          processPremiumPage(targetUrl)
        }
      });

    }
  }
}

// Utility function to check if a node is the specific meta tag we're interested in
function isTargetMetaTag(node) {
  return node.nodeName && node.nodeName.toLowerCase() === 'meta' &&
    node.getAttribute('property') === 'al:ios:url';
}

// Start observing the <head> element for changes to the specific meta tag
function startObservingHead() {
  const headElement = document.head;
  const config = {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['content'] // We only need to observe changes to the 'content' attribute
  };

  const observer = new MutationObserver(handleHeadMutation);
  observer.observe(headElement, config);

}

function processPremiumPage(targetUrl) {
  if (targetUrl) {
    const mediumPath = targetUrl.replace('medium://p/', 'https://medium.com/p/');
    let defaultUrl = 'https://freedium.cfd';

    const newUrl = `${defaultUrl}/${mediumPath}`;
    replaceContentWithIframe(newUrl);
  }
}

// Initiating the observation when the content script is executed
startObservingHead();

// Check for the meta tag and replace the content if matched
const metaTag = document.querySelector('meta[property="al:ios:url"]');
if (metaTag) {
  const targetUrl = metaTag.getAttribute('content');
  processPremiumPage(targetUrl)

}
