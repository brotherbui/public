export class ThemeHandler {

  constructor() {
    window
      .matchMedia('(prefers-color-scheme: dark)')
      .addEventListener('change', (event) => {
        console.log('theme changed!');
        this.updateTheme();
      });
  }

  /**
   * Handles which theme the page will be rendered with.
   */
  updateTheme() {
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    if (prefersDarkScheme.matches) {
      document.body.dataset.theme = 'dark';
    } else {
      document.body.dataset.theme = 'light';
    }
  
  }


}
