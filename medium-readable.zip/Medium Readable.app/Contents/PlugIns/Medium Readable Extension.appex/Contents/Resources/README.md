Auto process
