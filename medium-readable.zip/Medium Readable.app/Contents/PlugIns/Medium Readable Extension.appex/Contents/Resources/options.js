import { ThemeHandler } from './theme-handler.js';

document.addEventListener('DOMContentLoaded', async () => {
  const themeHandler = new ThemeHandler();
  themeHandler.updateTheme();
  
});
